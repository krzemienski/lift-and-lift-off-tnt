export function log(event:string){console.log(`[TNT] ${event} @ ${new Date().toISOString()}`)}
