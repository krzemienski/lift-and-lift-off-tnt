6‑post grid of latest content + **Follow** CTA.
