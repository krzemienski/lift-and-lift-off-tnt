Revelation:

My road to becoming a trainer wasn’t necessarily an upbeat story, although with all trials and tribulations “To the VICTOR must come the SPOILS”.

First day of my existence came with an asthma attack; over and over as a child asthma was my biggest enemy.
Grateful for my mother’s employment at Mount Sinai East, I was frequently seen in the ER without long waits. At the age of 10 I made the decision to stop taking my albuterol medication. As a youth I was engaged in many sports programs and my coaches were always in constant worry about my health, so this would compel them to sit me out of games. This fueled my early passion to produce and perform—this passion, years later, would soon heal me.

In July 2019, while working, a freight elevator door collapsed on my head due to faulty wires. It landed me in the hospital. I left the hospital with an MRI scan reading severe brain contusions and concussion, cervical spine damage (vertebrae C1–C5), and lumbar spine damage (L5–L7). This injury forced me into 2 years of cognitive and physical therapy and a year and a half of walking with support.

EVOLUTION:

In 2024, my journey of repairing my mental, spiritual and physical wellness led me to wanting to know more, so I began to learn about the human body. Self‑study later developed into returning to school, earning me three physical trainer certifications and a nutritionist certification.

Fitness is more than lifting weights; it’s more than aesthetic pleasure—fitness is wellness for the Mind, Spirit and Body.

Fitness has served and saved me and now it’s your turn. Are you ready?
