# Voice: clear, disciplined, motivating. Keep sentences tight. Emphasize accountability and form.
