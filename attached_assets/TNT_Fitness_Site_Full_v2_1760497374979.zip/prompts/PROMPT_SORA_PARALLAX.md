# Generate a 10s seamless parallax loop (kettlebells/battle ropes) in TNT palette; 4K, 24fps.
